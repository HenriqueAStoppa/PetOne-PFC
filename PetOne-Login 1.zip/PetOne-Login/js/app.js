const API = 'http://localhost:8080';

function authHeaders() {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function postJSON(url, body, withAuth=false) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(withAuth ? authHeaders() : {}) },
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json().catch(() => ({}));
}

async function getJSON(url, withAuth=false) {
  const res = await fetch(url, { headers: withAuth ? authHeaders() : {} });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

// ===== Login Tutor =====
const tutorLoginForm = document.querySelector('#form-login-tutor');
if (tutorLoginForm) {
  tutorLoginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = e.target.email.value.trim();
    const password = e.target.password.value;
    try {
      const data = await postJSON(`${API}/api/usuario/login`, { email, password });
      localStorage.setItem('token', data.token);
      alert('Login OK!');
      // Ex.: agora você pode acessar /tutors protegido:
      const tutors = await getJSON(`${API}/tutors`, true);
      console.log('Tutors protegidos:', tutors);
    } catch (err) {
      alert('Erro no login: ' + err.message);
    }
  });
}
